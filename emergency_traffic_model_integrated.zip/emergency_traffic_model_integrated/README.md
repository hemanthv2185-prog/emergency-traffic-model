# Emergency Congestion-Aware Route Optimizer + ML Prototype

This Streamlit demonstration combines OSRM road-following route alternatives with a trained congestion model. It keeps the selected start and destination fixed while comparing returned route options in different colours. The green route is the lowest-scoring option.

## Start in Windows / VS Code

Keep all files and folders in this project folder. Open the folder in VS Code (not the ZIP itself). In the terminal run:

```powershell
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
streamlit run app.py
```

If `.venv` does not exist, create it first:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
streamlit run app.py
```

## What's integrated

- `app.py`: emergency route comparison UI.
- `Final dp.xlsx`: historical dataset.
- `model_outputs/best_congestion_model.joblib`: trained Random Forest model selected by chronological holdout MAE.
- `model_outputs/model_comparison.csv` and `model_report.txt`: benchmark results and limitations.
- `train_model.py`: script to retrain/compare models if needed.

In the sidebar, enable **Use ML-predicted next-record congestion** to use the model estimates in route scoring. If disabled, the app uses historical average congestion. The model is applied to the latest available historical record per area/road, so it does NOT predict current live congestion. The dataset ends in 2024.

## Important limitations

- This is an academic prototype, not connected to India's 108 dispatch system.
- OSRM public demo routing may return only one alternative and may be rate-limited.
- OSRM's estimated duration is not a live traffic ETA.
- Route congestion is an area-level estimate assigned to sampled route points, not actual edge-level sensor readings.
- The ML target is the next recorded congestion observation, not a fixed 15/30-minute forecast.
- Verify all locations, data quality, road restrictions, model calibration, and emergency service requirements before any real-world use.
