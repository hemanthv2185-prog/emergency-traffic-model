"""
Train and compare congestion forecasting models on Final dp.xlsx.
Target: next recorded congestion level for the same area + road/intersection.
Uses chronological train/test split to reduce temporal leakage.
"""
from pathlib import Path
import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestRegressor, ExtraTreesRegressor, HistGradientBoostingRegressor, RandomForestClassifier
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.base import clone
import joblib

ROOT = Path(__file__).parent
DATA = ROOT / "Final dp.xlsx"
OUT = ROOT / "model_outputs"
OUT.mkdir(exist_ok=True)

def main():
    if not DATA.exists():
        raise FileNotFoundError("Put Final dp.xlsx in the same folder as train_model.py")

    raw = pd.read_excel(DATA, sheet_name="Connected_Routes")
    # Connected_Routes repeats source records once per connected route. Deduplicate first.
    df = raw.drop_duplicates(subset=["Source_Record_ID"]).copy()
    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    df = df.dropna(subset=["Date", "Area Name", "Road/Intersection Name", "Congestion Level"])
    df = df.sort_values(["Area Name", "Road/Intersection Name", "Date", "Source_Record_ID"])

    # Build a genuine next-observation target within each road/area time series.
    group_cols = ["Area Name", "Road/Intersection Name"]
    df["Target_Next_Congestion"] = df.groupby(group_cols)["Congestion Level"].shift(-1)
    df["Target_Next_Date"] = df.groupby(group_cols)["Date"].shift(-1)
    df = df.dropna(subset=["Target_Next_Congestion", "Target_Next_Date"]).copy()

    # Exclude connected-route columns, record IDs, current target, and next target date.
    # Current measurements are predictors for the next recorded congestion value.
    numeric = [
        "Traffic Volume", "Average Speed", "Travel Time Index",
        "Road Capacity Utilization", "Incident Reports", "Environmental Impact",
        "Public Transport Usage", "Traffic Signal Compliance", "Parking Usage",
        "Pedestrian and Cyclist Count"
    ]
    categorical = [
        "Area Name", "Road/Intersection Name",
        "Weather Conditions", "Roadwork and Construction Activity"
    ]
    for c in numeric:
        if c not in df:
            df[c] = np.nan
    for c in categorical:
        if c not in df:
            df[c] = "Unknown"

    # Date features known at prediction time.
    df["DayOfWeek"] = df["Date"].dt.dayofweek
    df["Month"] = df["Date"].dt.month
    df["DayOfYear"] = df["Date"].dt.dayofyear
    numeric += ["DayOfWeek", "Month", "DayOfYear"]

    features = numeric + categorical
    X = df[features].copy()
    y = df["Target_Next_Congestion"].astype(float)

    # Strict chronological split: earliest 80% train, latest 20% test.
    cutoff = df["Date"].quantile(0.80)
    train_mask = df["Date"] < cutoff
    test_mask = ~train_mask
    X_train, X_test = X.loc[train_mask], X.loc[test_mask]
    y_train, y_test = y.loc[train_mask], y.loc[test_mask]

    numeric_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scale", StandardScaler())
    ])
    categorical_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False))
    ])
    preprocess = ColumnTransformer([
        ("num", numeric_pipe, numeric),
        ("cat", categorical_pipe, categorical)
    ], remainder="drop")

    models = {
        "Random Forest": RandomForestRegressor(
            n_estimators=250, min_samples_leaf=2, max_features=0.9,
            random_state=42, n_jobs=-1
        ),
        "Extra Trees": ExtraTreesRegressor(
            n_estimators=250, min_samples_leaf=2, max_features=0.9,
            random_state=42, n_jobs=-1
        ),
        "HistGradientBoosting": HistGradientBoostingRegressor(
            max_iter=180, learning_rate=0.07, l2_regularization=1.0,
            random_state=42
        )
    }

    results = []
    fitted = {}
    for name, model in models.items():
        pipe = Pipeline([("preprocess", clone(preprocess)), ("model", model)])
        pipe.fit(X_train, y_train)
        pred = np.clip(pipe.predict(X_test), 0, 100)
        results.append({
            "Model": name,
            "MAE (lower is better)": mean_absolute_error(y_test, pred),
            "RMSE (lower is better)": mean_squared_error(y_test, pred) ** 0.5,
            "R2 (higher is better)": r2_score(y_test, pred),
            "Test rows": len(y_test)
        })
        fitted[name] = pipe

    # Simple persistence baseline: next congestion ~= current congestion.
    baseline = np.clip(df.loc[test_mask, "Congestion Level"].astype(float).values, 0, 100)
    results.append({
        "Model": "Persistence baseline (current congestion)",
        "MAE (lower is better)": mean_absolute_error(y_test, baseline),
        "RMSE (lower is better)": mean_squared_error(y_test, baseline) ** 0.5,
        "R2 (higher is better)": r2_score(y_test, baseline),
        "Test rows": len(y_test)
    })
    metrics = pd.DataFrame(results).sort_values("MAE (lower is better)")
    metrics.to_csv(OUT / "model_comparison.csv", index=False)

    # Select best learned model by chronological holdout MAE, not by training score.
    learned = metrics[metrics["Model"].isin(models.keys())]
    best_name = learned.iloc[0]["Model"]
    best_pipe = fitted[best_name]
    joblib.dump({
        "pipeline": best_pipe,
        "model_name": best_name,
        "numeric_features": numeric,
        "categorical_features": categorical,
        "features": features,
        "target": "next recorded Congestion Level",
        "training_cutoff_date": str(cutoff.date())
    }, OUT / "best_congestion_model.joblib")

    # Save a concise text report for mentor/demo.
    report = [
        "TRAFFIC CONGESTION FORECASTING MODEL REPORT",
        "=" * 48,
        f"Workbook rows: {len(raw)}",
        f"Unique source observations after deduplication: {raw['Source_Record_ID'].nunique()}",
        f"Forecasting samples with a next observation: {len(df)}",
        f"Chronological training rows: {len(X_train)}",
        f"Chronological test rows: {len(X_test)}",
        f"Train/test cutoff date: {cutoff.date()}",
        f"Selected model by lowest holdout MAE: {best_name}",
        "",
        metrics.to_string(index=False),
        "",
        "Interpretation: target is the next recorded congestion level for the same area/road.",
        "This is forecasting of the next available record, not a guaranteed fixed 15/30-minute forecast.",
        "Dataset has historical observations, not live traffic. Validate target timing and data provenance before claiming real-time prediction."
    ]
    (OUT / "model_report.txt").write_text("\n".join(report), encoding="utf-8")

    # Export test predictions for plots/demo.
    pred = np.clip(best_pipe.predict(X_test), 0, 100)
    pred_out = df.loc[test_mask, ["Date", "Area Name", "Road/Intersection Name", "Congestion Level", "Target_Next_Congestion"]].copy()
    pred_out["Predicted_Next_Congestion"] = pred
    pred_out.to_csv(OUT / "test_predictions.csv", index=False)

    print("\nMODEL COMPARISON (chronological holdout)")
    print(metrics.to_string(index=False))
    print(f"\nSelected: {best_name}")
    print(f"Outputs saved in: {OUT}")
    print("Read model_outputs/model_report.txt before presenting results.")

if __name__ == "__main__":
    main()
